package com.example.FOYERBI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoyerbiApplicationTests {

	@Test
	void contextLoads() {
	}

}
